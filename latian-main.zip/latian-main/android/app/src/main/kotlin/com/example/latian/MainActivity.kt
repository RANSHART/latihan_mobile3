package com.example.latian

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
